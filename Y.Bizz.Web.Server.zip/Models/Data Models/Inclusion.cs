﻿namespace Y.Bizz.Web.Server
{
  public class Inclusion
  {
    #region Public Properties
    /// <summary>
    /// Inclusion ID
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Inclusion Name
    /// </summary>
    public string Name { get; set; }
    #endregion
  }
}
