﻿namespace Y.Bizz.Web.Server
{
    /// <summary>
    /// The result of a register request via API
    /// </summary>
    public class RegisterResultApiModel : LoginResultApiModel
    {

    }
}
